import random

uplatter = "ABCDEFGHIJKLMNOPQSTUVWXYZ"
lowlatter = uplatter.lower()
digits ="0123456789"
symboles="+-*/_=)(&%$#৥![]<>?|,."

uper , lowar , number, symbol = True, True, True, True
add =""

if uper:
    add+=uplatter
if lowar:
    add+=lowlatter
if number:
    add+=digits
if symbol:
    add+=symboles

length = 10
amount = 5

for x in range(amount):
    passwaord ="". join(random.sample(add,length))
    print(passwaord)